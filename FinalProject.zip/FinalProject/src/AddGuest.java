public class AddGuest extends Guest {
    
    public void addGuest(Guest g){
        guests.add(g);
    }
}
// public void btnNext(ActionEvent event)throws FileNotFoundException, IOException,ClassNotFoundException{
        //     if(count< guestNew.size()){
        //         Guest g = new Guest();
        //         g= guestNew.get(count);
        //         txtFullName.setText(g.getFullName());
                
                
        //         count++;
        //     }
        // }



        // //name column
        // TableColumn<Guest, String> nameCol = new TableColumn<>("Name");
        // nameCol.setMinWidth(200);
        // nameCol.setCellValueFactory(new PropertyValueFactory<>("fullName"));

        // //Contact column
        // TableColumn<Guest, Integer> contactCol = new TableColumn<>("Contact");
        // contactCol.setMinWidth(100);
        // contactCol.setCellValueFactory(new PropertyValueFactory<>(""));

        // //Email column
        // TableColumn<Guest, String> emailCol = new TableColumn<>("Email");
        // emailCol.setMinWidth(200);
        // emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));

        // //check in column
        // TableColumn<Guest, String> checkInColumn = new TableColumn<>("Check - In");
        // checkInColumn.setMinWidth(200);
        // checkInColumn.setCellValueFactory(new PropertyValueFactory<>("checkInDate"));

        // //check out column
        // TableColumn<Guest, String> checkOutColumn = new TableColumn<>("Check - Out");
        // checkOutColumn.setMinWidth(200);
        // checkOutColumn.setCellValueFactory(new PropertyValueFactory<>("checkOutDate"));

        // //Room# column
        // TableColumn<Guest, Integer> roomNoCol = new TableColumn<>("Room No.");
        // roomNoCol.setMinWidth(100);
        // roomNoCol.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));        