// public class EditGuest extends Guest{

//     // public EditGuest(){
//     //     this(String fname, contactNumber, email, checkInDate, checkOutDate, roomNumber, editedGuest)
//     // }

    
//     //Guest editedGuest = new Guest(fullName, contactNumber, email, checkInDate, checkOutDate, roomNumber)
//     public EditGuest(String fullName, int contactNumber, String email, String checkInDate, String checkOutDate,
//     int roomNumber, Guest editedGuest) {

//         super(fullName, contactNumber, email, checkInDate, checkOutDate, roomNumber);

//     }

//     // {
//     //     super(fullName, contactNumber, email, checkInDate, checkOutDate, roomNumber);
//     //     this.fullname = fullname;
//     //     this.ContactNumber = contactNumber;
//     //     this.email = email;
//     //     this.checkInDate = checkInDate;
//     //     this.checkOutDate = checkOutDate;
//     //     this.roomNumber = roomNumber;
//     // }

//     //still under work
//     public void editGuest(Guest g){

//         guests.set(guests.indexOf(g), new EditGuest() );
//     }
// }

